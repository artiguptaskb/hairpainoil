 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Checkout - Techno Smarter </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-12 form-container">
				<h1>Checkout</h1>
<hr>		
				<div class="row"> 
					<div class="col-8"> 
<form action="pay.php" method="POST">
					<div class="col-4 text-center">
						
      <div class="card" style="width: 18rem;">
  <img class="card-img-top" src="https://media.swipepages.com/2023/3/5ff6c1a81bb3e30010dc353a/adityawebsite_12_1080x1296-750.webp" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Hair Oil</h5>
    <p class="card-text"> 239 INR</p>
    <input type="hidden" value="239"  name="price">
  </div>
</div>
				<br>
				  <button type="submit" class="btn btn-primary" name="submit_form">Place Order</button>
	</form>
				</div>
				</div>
		</div>
	</div>
</div>
</body>
</html>



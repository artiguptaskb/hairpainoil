let array=["10","20","30","50"];
for(let i =0; i<array.length; i++){
        console.log(i);
        // document.write(i)
    }